import React from 'react';

interface ChatMessageProps {
  role: 'user' | 'assistant';
  content: string;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ role, content }) => (
  <div className={`p-3 rounded-lg mb-2 ${
    role === 'user' 
      ? 'bg-blue-100 ml-auto max-w-[80%]' 
      : 'bg-gray-100 mr-auto max-w-[80%]'
  }`}>
    <p className="text-sm text-gray-800">{content}</p>
  </div>
);

export default ChatMessage;
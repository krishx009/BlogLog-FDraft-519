import React from 'react';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import { Message } from '../../types';

interface ChatBoxProps {
  messages: Message[];
  isLoading: boolean;
  onSendMessage: (message: string) => Promise<void>;
}

const ChatBox: React.FC<ChatBoxProps> = ({ messages, isLoading, onSendMessage }) => {
  return (
    <div className="border rounded-lg p-4 bg-white shadow-md">
      <h2 className="text-xl font-semibold mb-4">Chat with AI</h2>
      <div className="h-[300px] overflow-y-auto mb-4 space-y-2">
        {messages.map((message, index) => (
          <ChatMessage
            key={index}
            role={message.role}
            content={message.content}
          />
        ))}
        {isLoading && (
          <div className="text-sm text-gray-500 italic">AI is thinking...</div>
        )}
      </div>
      <ChatInput onSendMessage={onSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default ChatBox;
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { Blog, BlogSummaries } from '../types';
import { useAuth } from '../AuthContext';
import { useChat } from '../hooks/useChat';
import Navbar from './Navbar';
import NewBlogPost from './NewBlogPost';
import ChatBox from './Chat/ChatBox';

const API_URL = 'http://localhost:5000/api';

const BlogTopicPage: React.FC = () => {
  const { topic } = useParams<{ topic: string }>();
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [showNewPostForm, setShowNewPostForm] = useState(false);
  const [summaries, setSummaries] = useState<BlogSummaries>({});
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const { messages, isLoading, sendMessage } = useChat();

  useEffect(() => {
    fetchBlogs();
  }, [topic]);

  const fetchBlogs = async () => {
    try {
      const response = await axios.get(`${API_URL}/blogs/topic/${topic}`);
      setBlogs(response.data);
    } catch (error) {
      console.error('Error fetching blogs:', error);
      alert('Failed to fetch blogs. Please try again later.');
    }
  };

  const addNewBlog = async (blogData: any) => {
    try {
      await axios.post(
        `${API_URL}/blogs`,
        { ...blogData, topic },
        { withCredentials: true }
      );
      fetchBlogs();
      setShowNewPostForm(false);
    } catch (error) {
      console.error('Error creating blog:', error);
      alert('Failed to create a new blog. Please try again later.');
    }
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const summarizeBlog = async (blogId: string, content: string) => {
    setLoading(true);
    try {
      const summaryResponse = await axios.post(`${API_URL}/ai/summarize`, {
        text: content,
      });
      setSummaries(prev => ({
        ...prev,
        [blogId]: summaryResponse.data.summary,
      }));
    } catch (error) {
      console.error('Error summarizing blog:', error);
      alert('Failed to summarize the blog.');
    } finally {
      setLoading(false);
    }
  };

  const clearSummary = (blogId: string) => {
    setSummaries(prev => {
      const newSummaries = { ...prev };
      delete newSummaries[blogId];
      return newSummaries;
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar showLoginButton={true} />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 capitalize">
            {topic}
          </h1>
        </div>

        {user && (
          <div className="mb-8">
            <button
              onClick={() => setShowNewPostForm(true)}
              className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition"
            >
              Add New Post
            </button>
          </div>
        )}

        {showNewPostForm && (
          <NewBlogPost
            onSubmit={addNewBlog}
            onCancel={() => setShowNewPostForm(false)}
          />
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {blogs.length > 0 ? (
              <div className="space-y-6">
                {blogs.map((blog) => (
                  <div key={blog._id} className="bg-white rounded-lg shadow-md p-6">
                    <h2 className="text-xl font-semibold mb-3">{blog.title}</h2>
                    <p className="text-gray-600 mb-4">
                      {blog.content.substring(0, 100)}...
                    </p>
                    <p className="text-sm text-gray-500 mb-4">
                      Posted on: {formatDate(blog.createdAt)}
                    </p>
                    <div className="flex gap-3">
                      <Link
                        to={`/blog/${blog._id}`}
                        className="text-blue-500 hover:text-blue-600"
                      >
                        Read More
                      </Link>
                      <button
                        onClick={() => summarizeBlog(blog._id, blog.content)}
                        className="text-green-500 hover:text-green-600"
                        disabled={loading}
                      >
                        {loading ? 'Summarizing...' : 'Summarize'}
                      </button>
                    </div>
                    {summaries[blog._id] && (
                      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-700">{summaries[blog._id]}</p>
                        <button
                          onClick={() => clearSummary(blog._id)}
                          className="text-red-500 text-sm mt-2 hover:text-red-600"
                        >
                          Clear Summary
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No blogs found for this topic.</p>
            )}
          </div>

          <div className="lg:col-span-1">
            <ChatBox
              messages={messages}
              isLoading={isLoading}
              onSendMessage={sendMessage}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogTopicPage;
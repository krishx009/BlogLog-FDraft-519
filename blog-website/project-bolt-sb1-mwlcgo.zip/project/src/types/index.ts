export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export interface Blog {
  _id: string;
  title: string;
  content: string;
  createdAt: string;
}

export interface BlogSummaries {
  [key: string]: string;
}